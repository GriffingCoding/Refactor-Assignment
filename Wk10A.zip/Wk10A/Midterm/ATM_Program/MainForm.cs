﻿using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace ATM_Program
{


    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        private void Exit_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            LoginForm fm = new LoginForm();
            fm.Show();
        }

        //Show Account Information
        private void Account_Information_btn_Click(object sender, EventArgs e)
        {
            int id;
            id = 1;

            List<Bank> bank = SQLHelper.AccountInfo(id);
            foreach (Bank x in bank)
            {
                List_Box.Items.Add("Savings Balance: " + x.Savings.ToString());
                List_Box.Items.Add("Checking Balance: " + x.Checking.ToString());
                List_Box.Items.Add("Account Total Balance: " + x.Account.ToString());
            }
        }

        //Show Savings Screen
        private void Savings_Account_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Savings_Account_Screen fm = new Savings_Account_Screen();
            fm.Show();
        }

        //Show Checking Screen
        private void Checking_Account_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            Checking_Account_Screen fm = new Checking_Account_Screen();
            fm.Show();
        }
    }
}
