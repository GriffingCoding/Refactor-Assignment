﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;



namespace ATM_Program
{
    class SQLHelper
    {
        public static List<Bank> AccountInfo(int id)
        {
            string connectionString;
            connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\dagri\OneDrive\Desktop\Programming II\Wk10A\Midterm\ATM_Program\ApplicationDatabase.mdf"";Integrated Security=True";
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = connection.CreateCommand();
            connection.Open();

            command.CommandText = "Select * FROM Bank WHERE Id = '" + id + "'";

            SqlDataReader dataReader = command.ExecuteReader();

            List<Bank> myAccount = new List<Bank>();
            while (dataReader.Read())
            {
                Bank bank = new Bank();
                bank.Checking = Convert.ToDecimal(dataReader.GetValue(2));
                bank.Savings = Convert.ToDecimal(dataReader.GetValue(3));
                bank.Account = bank.Savings + bank.Checking;
                myAccount.Add(bank);
            }
            command.Dispose();
            connection.Close();
            return myAccount;
        }

        public static void Deposit(decimal funds, int id, string checkorsave)
        {
            decimal check;
            decimal save;
            decimal amountS;
            decimal amountC;
            string connectionString;
            SqlConnection con;
            connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\dagri\OneDrive\Desktop\Programming II\Wk10A\Midterm\ATM_Program\ApplicationDatabase.mdf"";Integrated Security=True";
            con = new SqlConnection(connectionString);
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = connection.CreateCommand();
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql;
            connection.Open();
            command.CommandText = "Select * FROM Bank WHERE Id = '" + id + "'";
            SqlDataReader dataReader = command.ExecuteReader();

            List<Bank> myAccount = new List<Bank>();
            while (dataReader.Read())
            {
                Bank bank = new Bank();
                bank.Checking = Convert.ToDecimal(dataReader.GetValue(2));
                bank.Savings = Convert.ToDecimal(dataReader.GetValue(3));
                myAccount.Add(bank);
            }

            var firstElecemnt = myAccount[0].Checking;
            var secondElement = myAccount[0].Savings;
            check = Convert.ToDecimal(firstElecemnt);
            save = Convert.ToDecimal(secondElement);
            amountS = save + funds;
            amountC = check + funds;

            if (checkorsave == "save")
            {
                sql = "UPDATE [Bank]" +
                    " SET Savings = '" + amountS + "'" +
                    " WHERE Id='" + id + "'";
                command = new SqlCommand(sql, con);
                con.Open();
                adapter.InsertCommand = new SqlCommand(sql, con);
                adapter.InsertCommand.ExecuteNonQuery();
                command.Dispose();
                con.Close();
            }
            if (checkorsave == "check")
            {
                sql = "UPDATE [Bank]" +
                    " SET Checking = '" + amountC + "'" +
                    " WHERE Id='" + id + "'";
                command = new SqlCommand(sql, con);
                con.Open();
                adapter.InsertCommand = new SqlCommand(sql, con);
                adapter.InsertCommand.ExecuteNonQuery();
                command.Dispose();
                con.Close();
            }
        }


        public static string Withdrawl(decimal funds, int id, string checkorsave)
        {
            decimal check;
            decimal save;
            decimal amountS;
            decimal amountC;
            string connectionString;
            SqlConnection con;
            connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\dagri\OneDrive\Desktop\Programming II\Wk10A\Midterm\ATM_Program\ApplicationDatabase.mdf"";Integrated Security=True";
            con = new SqlConnection(connectionString);
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = connection.CreateCommand();
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql;
            connection.Open();
            command.CommandText = "Select * FROM Bank WHERE Id = '" + id + "'";
            SqlDataReader dataReader = command.ExecuteReader();

            List<Bank> myAccount = new List<Bank>();
            while (dataReader.Read())
            {
                Bank bank = new Bank();
                bank.Checking = Convert.ToDecimal(dataReader.GetValue(2));
                bank.Savings = Convert.ToDecimal(dataReader.GetValue(3));
                myAccount.Add(bank);
            }

            var firstElecemnt = myAccount[0].Checking;
            var secondElement = myAccount[0].Savings;

            check = Convert.ToDecimal(firstElecemnt);
            save = Convert.ToDecimal(secondElement);

            amountS = save - funds;
            amountC = check - funds;
            decimal zero = 0;

            if (checkorsave == "save")
            {
                if (amountS < zero)
                {
                    return "no";
                }
                if (amountS >= zero)
                {
                    sql = "UPDATE [Bank]" +
                        " SET Savings = '" + amountS + "'" +
                        " WHERE Id='" + id + "'";
                    command = new SqlCommand(sql, con);
                    con.Open();
                    adapter.InsertCommand = new SqlCommand(sql, con);
                    adapter.InsertCommand.ExecuteNonQuery();
                    command.Dispose();
                    con.Close();
                    return "yes";
                }
            }

            else if (checkorsave == "check")
            {
                if (amountC < zero)
                {
                    if (amountS < zero)
                    {
                        return "no";
                    }
                    if (amountS >= zero)
                    {
                        sql = "UPDATE [Bank]" +
                            " SET Savings = '" + amountS + "'" +
                            " WHERE Id='" + id + "'";
                        command = new SqlCommand(sql, con);
                        con.Open();
                        adapter.InsertCommand = new SqlCommand(sql, con);
                        adapter.InsertCommand.ExecuteNonQuery();
                        command.Dispose();
                        con.Close();
                        return "yes";
                    }
                }
                if (amountC >= zero)
                {
                    sql = "UPDATE [Bank]" +
                    " SET Checking = '" + amountC + "'" +
                    " WHERE Id='" + id + "'";
                    command = new SqlCommand(sql, con);
                    con.Open();
                    adapter.InsertCommand = new SqlCommand(sql, con);
                    adapter.InsertCommand.ExecuteNonQuery();
                    command.Dispose();
                    con.Close();
                    return "yes";
                }
            }
            return "done";
        }
        public static string Transfer(decimal funds, int id, string checkorsave)
        {
            decimal check;
            decimal save;
            decimal transferFrom;
            decimal transferTo;
            string connectionString;
            SqlConnection con;
            connectionString = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\dagri\OneDrive\Desktop\Programming II\Wk10A\Midterm\ATM_Program\ApplicationDatabase.mdf"";Integrated Security=True";
            con = new SqlConnection(connectionString);
            SqlConnection connection = new SqlConnection(connectionString);
            SqlCommand command = connection.CreateCommand();
            SqlDataAdapter adapter = new SqlDataAdapter();
            string sql;
            connection.Open();
            command.CommandText = "Select * FROM Bank WHERE Id = '" + id + "'";
            SqlDataReader dataReader = command.ExecuteReader();

            List<Bank> myAccount = new List<Bank>();
            while (dataReader.Read())
            {
                Bank bank = new Bank();
                bank.Checking = Convert.ToDecimal(dataReader.GetValue(2));
                bank.Savings = Convert.ToDecimal(dataReader.GetValue(3));
                myAccount.Add(bank);
            }

            var firstElecemnt = myAccount[0].Checking;
            var secondElement = myAccount[0].Savings;
            check = Convert.ToDecimal(firstElecemnt);
            save = Convert.ToDecimal(secondElement);
            transferFrom = save - funds;
            transferTo = check + funds;
            decimal zero = 0;

            if (checkorsave == "save")
            {
                if (transferFrom < zero)
                {
                    return "no";
                }
                else if (transferFrom >= zero)
                {
                    sql = "UPDATE [Bank]" +
                    " SET Savings = '" + transferFrom + "', Checking = '" + transferTo + "'" +
                    " WHERE Id='" + id + "'";
                    command = new SqlCommand(sql, con);
                    con.Open();
                    adapter.InsertCommand = new SqlCommand(sql, con);
                    adapter.InsertCommand.ExecuteNonQuery();
                    command.Dispose();
                    con.Close();
                    return "yes";
                }
            }

            if (checkorsave == "check")
            {
                if (transferFrom < zero)
                {
                    return "no";
                }
                else if (transferFrom >= zero)
                {
                    sql = "UPDATE [Bank]" +
                    " SET Checking = '" + transferFrom + "'and Savings = '" + transferTo + "'" +
                    " WHERE Id='" + id + "'";
                    command = new SqlCommand(sql, con);
                    con.Open();
                    adapter.InsertCommand = new SqlCommand(sql, con);
                    adapter.InsertCommand.ExecuteNonQuery();
                    command.Dispose();
                    con.Close();
                    return "yes";
                }
            }
            return "done";
        }
    }
}
