﻿
namespace ATM_Program
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.Checking_Account_btn = new System.Windows.Forms.Button();
            this.Account_Information_btn = new System.Windows.Forms.Button();
            this.Savings_Account_btn = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.Exit_btn = new System.Windows.Forms.Button();
            this.List_Box = new System.Windows.Forms.ListBox();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(51, 35);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(420, 280);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // Checking_Account_btn
            // 
            this.Checking_Account_btn.Location = new System.Drawing.Point(371, 73);
            this.Checking_Account_btn.Name = "Checking_Account_btn";
            this.Checking_Account_btn.Size = new System.Drawing.Size(90, 23);
            this.Checking_Account_btn.TabIndex = 1;
            this.Checking_Account_btn.Text = "Checking";
            this.Checking_Account_btn.UseVisualStyleBackColor = true;
            this.Checking_Account_btn.Click += new System.EventHandler(this.Checking_Account_btn_Click);
            // 
            // Account_Information_btn
            // 
            this.Account_Information_btn.Location = new System.Drawing.Point(371, 195);
            this.Account_Information_btn.Name = "Account_Information_btn";
            this.Account_Information_btn.Size = new System.Drawing.Size(90, 23);
            this.Account_Information_btn.TabIndex = 2;
            this.Account_Information_btn.Text = "Account Info.";
            this.Account_Information_btn.UseVisualStyleBackColor = true;
            this.Account_Information_btn.Click += new System.EventHandler(this.Account_Information_btn_Click);
            // 
            // Savings_Account_btn
            // 
            this.Savings_Account_btn.Location = new System.Drawing.Point(371, 134);
            this.Savings_Account_btn.Name = "Savings_Account_btn";
            this.Savings_Account_btn.Size = new System.Drawing.Size(90, 23);
            this.Savings_Account_btn.TabIndex = 3;
            this.Savings_Account_btn.Text = "Savings";
            this.Savings_Account_btn.UseVisualStyleBackColor = true;
            this.Savings_Account_btn.Click += new System.EventHandler(this.Savings_Account_btn_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(159, 99);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 15);
            this.label1.TabIndex = 4;
            // 
            // Exit_btn
            // 
            this.Exit_btn.Location = new System.Drawing.Point(371, 256);
            this.Exit_btn.Name = "Exit_btn";
            this.Exit_btn.Size = new System.Drawing.Size(90, 23);
            this.Exit_btn.TabIndex = 5;
            this.Exit_btn.Text = "Exit";
            this.Exit_btn.UseVisualStyleBackColor = true;
            this.Exit_btn.Click += new System.EventHandler(this.Exit_btn_Click);
            // 
            // List_Box
            // 
            this.List_Box.FormattingEnabled = true;
            this.List_Box.ItemHeight = 15;
            this.List_Box.Location = new System.Drawing.Point(89, 106);
            this.List_Box.Name = "List_Box";
            this.List_Box.Size = new System.Drawing.Size(248, 139);
            this.List_Box.TabIndex = 8;
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(532, 370);
            this.Controls.Add(this.List_Box);
            this.Controls.Add(this.Exit_btn);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Savings_Account_btn);
            this.Controls.Add(this.Account_Information_btn);
            this.Controls.Add(this.Checking_Account_btn);
            this.Controls.Add(this.pictureBox1);
            this.Name = "MainForm";
            this.Text = "Form1";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button Checking_Account_btn;
        private System.Windows.Forms.Button Account_Information_btn;
        private System.Windows.Forms.Button Savings_Account_btn;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button Exit_btn;
        private System.Windows.Forms.ListBox List_Box;
    }
}