﻿using System.Collections.Generic;

namespace ATM_Program
{
    class Bank
    {

        public decimal Checking { get; set; }

        public decimal Savings { get; set; }

        public decimal Account { get; set; }
    }
}
