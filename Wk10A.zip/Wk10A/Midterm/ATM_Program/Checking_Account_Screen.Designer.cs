﻿
namespace ATM_Program
{
    partial class Checking_Account_Screen
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Checking_Account_Screen));
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label3 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.Return_btn = new System.Windows.Forms.Button();
            this.Balance_BoxC = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.Funds_Input = new System.Windows.Forms.TextBox();
            this.Deposit_btn = new System.Windows.Forms.Button();
            this.Withdrawal_btn = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.Transfer_btn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(61, 48);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(361, 214);
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.BackColor = System.Drawing.SystemColors.Window;
            this.label3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label3.Location = new System.Drawing.Point(171, 198);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(64, 20);
            this.label3.TabIndex = 3;
            this.label3.Text = "Balance:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.BackColor = System.Drawing.SystemColors.Window;
            this.label5.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label5.Location = new System.Drawing.Point(171, 127);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(0, 20);
            this.label5.TabIndex = 5;
            // 
            // Return_btn
            // 
            this.Return_btn.Location = new System.Drawing.Point(312, 154);
            this.Return_btn.Name = "Return_btn";
            this.Return_btn.Size = new System.Drawing.Size(76, 23);
            this.Return_btn.TabIndex = 6;
            this.Return_btn.Text = "Return";
            this.Return_btn.UseVisualStyleBackColor = true;
            this.Return_btn.Click += new System.EventHandler(this.Return_btn_Click);
            // 
            // Balance_BoxC
            // 
            this.Balance_BoxC.AutoSize = true;
            this.Balance_BoxC.BackColor = System.Drawing.SystemColors.Window;
            this.Balance_BoxC.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.Balance_BoxC.Location = new System.Drawing.Point(261, 198);
            this.Balance_BoxC.Name = "Balance_BoxC";
            this.Balance_BoxC.Size = new System.Drawing.Size(48, 20);
            this.Balance_BoxC.TabIndex = 8;
            this.Balance_BoxC.Text = "      .   ";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.BackColor = System.Drawing.SystemColors.Window;
            this.label1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label1.Location = new System.Drawing.Point(238, 198);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(17, 20);
            this.label1.TabIndex = 9;
            this.label1.Text = "$";
            // 
            // Funds_Input
            // 
            this.Funds_Input.Location = new System.Drawing.Point(171, 124);
            this.Funds_Input.Name = "Funds_Input";
            this.Funds_Input.PlaceholderText = "Enter Amount ";
            this.Funds_Input.Size = new System.Drawing.Size(135, 23);
            this.Funds_Input.TabIndex = 10;
            // 
            // Deposit_btn
            // 
            this.Deposit_btn.Location = new System.Drawing.Point(312, 124);
            this.Deposit_btn.Name = "Deposit_btn";
            this.Deposit_btn.Size = new System.Drawing.Size(76, 23);
            this.Deposit_btn.TabIndex = 11;
            this.Deposit_btn.Text = "Deposit";
            this.Deposit_btn.UseVisualStyleBackColor = true;
            this.Deposit_btn.Click += new System.EventHandler(this.Deposit_btn_Click);
            // 
            // Withdrawal_btn
            // 
            this.Withdrawal_btn.Location = new System.Drawing.Point(312, 94);
            this.Withdrawal_btn.Name = "Withdrawal_btn";
            this.Withdrawal_btn.Size = new System.Drawing.Size(76, 23);
            this.Withdrawal_btn.TabIndex = 12;
            this.Withdrawal_btn.Text = "Withdrawal";
            this.Withdrawal_btn.UseVisualStyleBackColor = true;
            this.Withdrawal_btn.Click += new System.EventHandler(this.Withdrawal_btn_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.BackColor = System.Drawing.SystemColors.Info;
            this.label2.Font = new System.Drawing.Font("Segoe UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point);
            this.label2.Location = new System.Drawing.Point(138, 54);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(200, 28);
            this.label2.TabIndex = 13;
            this.label2.Text = "CHECKING ACCOUNT";
            // 
            // Transfer_btn
            // 
            this.Transfer_btn.Location = new System.Drawing.Point(86, 116);
            this.Transfer_btn.Name = "Transfer_btn";
            this.Transfer_btn.Size = new System.Drawing.Size(75, 38);
            this.Transfer_btn.TabIndex = 14;
            this.Transfer_btn.Text = "Transfer to Savings";
            this.Transfer_btn.UseVisualStyleBackColor = true;
            this.Transfer_btn.Click += new System.EventHandler(this.Transfer_btn_Click);
            // 
            // Checking_Account_Screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(7F, 15F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.WindowFrame;
            this.ClientSize = new System.Drawing.Size(484, 311);
            this.Controls.Add(this.Transfer_btn);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.Withdrawal_btn);
            this.Controls.Add(this.Deposit_btn);
            this.Controls.Add(this.Funds_Input);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.Balance_BoxC);
            this.Controls.Add(this.Return_btn);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.pictureBox1);
            this.Name = "Checking_Account_Screen";
            this.Text = "Checking_Screen";
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button Return_btn;
        private System.Windows.Forms.Label Balance_BoxC;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox Funds_Input;
        private System.Windows.Forms.Button Deposit_btn;
        private System.Windows.Forms.Button Withdrawal_btn;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button Transfer_btn;
    }
}