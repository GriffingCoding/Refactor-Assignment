﻿using System;
using System.Windows.Forms;

namespace ATM_Program
{
    public partial class Checking_Account_Screen : Form
    {
        public Checking_Account_Screen()
        {
            InitializeComponent();
        }

        private void Withdrawal_btn_Click(object sender, EventArgs e)
        {
            decimal funds;
            int id;
            string checkorsave;
            checkorsave = "check";
            id = 1;
            funds = Convert.ToDecimal(Funds_Input.Text);
            SQLHelper.Withdrawl(funds, id, checkorsave);
            if (SQLHelper.Withdrawl(funds, id, checkorsave) == "yes")
            {
                MessageBox.Show("Withdrawl Complete.");
            }
            else if (SQLHelper.Withdrawl(funds, id, checkorsave) == "no")
            {
                MessageBox.Show("No more money in this account..");
            }
        }

        private void Deposit_btn_Click(object sender, EventArgs e)
        {
            decimal funds;
            int id;
            string checkorsave;
            checkorsave = "check";
            id = 1;
            funds = Convert.ToDecimal(Funds_Input.Text);
            SQLHelper.Deposit(funds, id, checkorsave);
            MessageBox.Show("Deposit Complete.");
        }

        private void Return_btn_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm fm = new MainForm();
            fm.Show();
        }

        private void Transfer_btn_Click(object sender, EventArgs e)
        {
            decimal funds;
            int id;
            string checkorsave;
            checkorsave = "check";
            id = 1;
            funds = Convert.ToDecimal(Funds_Input.Text);
            SQLHelper.Transfer(funds, id, checkorsave);
            if (SQLHelper.Transfer(funds, id, checkorsave) == "yes")
            {
                MessageBox.Show("Withdrawl Complete.");
            }
            if (SQLHelper.Transfer(funds, id, checkorsave) == "no")
            {
                MessageBox.Show("No more money in this account..");
            }
        }
    }
}
