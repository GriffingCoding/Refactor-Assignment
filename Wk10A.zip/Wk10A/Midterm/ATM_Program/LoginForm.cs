﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ATM_Program
{
    public partial class LoginForm : Form
    {
        public LoginForm()
        {
            InitializeComponent();
        }

        //Connection String
        string cs = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=""C:\Users\dagri\OneDrive\Desktop\Programming II\Midterm\ATM_Program\ApplicationDatabase.mdf"";Integrated Security=True;Connect Timeout=30";

        private void Enter_btn_Click(object sender, EventArgs e)
        {
            if (ID_Input.Text == "" || PIN_Input.Text == "")
            {
                MessageBox.Show("Please provide ID and PIN Number.");
                return;
            }
            try
            {
                SqlConnection con = new SqlConnection(cs);
                SqlCommand cmd = new SqlCommand("Select * from [Bank] where PIN=@pin and ID=@id", con);
                cmd.Parameters.AddWithValue("@pin", PIN_Input.Text);
                cmd.Parameters.AddWithValue("@id", ID_Input.Text);
                con.Open();
                SqlDataAdapter adapt = new SqlDataAdapter(cmd);
                DataSet ds = new DataSet();
                adapt.Fill(ds);
                con.Close();
                int count = ds.Tables[0].Rows.Count;
                //If count is equal to 1, than show frmMain form
                if (count == 1)
                {
                    MessageBox.Show("Login Successful!");
                    this.Hide();
                    MainForm fm = new MainForm();
                    fm.Show();
                }
                else
                {
                    MessageBox.Show("Login Failed!");
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
