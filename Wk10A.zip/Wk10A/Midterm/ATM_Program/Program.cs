using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ATM_Program
{
    // Describe what unit testing is and what its benefits are. pgs 904-912 - 7.5 points
    //
    // Writing a program that tests a certain method or class. A typical unit test executes the method that should be tested, passes a sample data to
    // (parameters and object states) and checks whether the method�s result is correct. Generally typical to border to incorrect cases to be sure the program will work in all senarios.
    // This can boost code quality, design, and efficiency, finding early bugs and providing documentation. Unit testing also allows the tests to be executed continuously, catching the 
    // bug almost instantly.
    //

    static class Program
    {
        /// <summary>
        ///  The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.SetHighDpiMode(HighDpiMode.SystemAware);
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            MessageBox.Show("Your ID is '1', and pin is '12345'\n\nNumber Buttons are in place to make application look like an ATM, Please type in your ID and PIN.\n\n'Enter' is truly the only button you use.", "Login Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            Application.Run(new LoginForm());
        }
    }
}
